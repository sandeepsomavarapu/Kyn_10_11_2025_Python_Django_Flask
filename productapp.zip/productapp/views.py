from django.shortcuts import render
from .models import Product
# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render,redirect,get_object_or_404

def product_list(request):
    products=Product.objects.all()
    return render(request,'productapp/product_list.html',{'products':products})

def product_create(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        price = request.POST.get('price')
        description = request.POST.get('description')
        stock = request.POST.get('stock')
        product = Product(name=name, price=price, description=description, stock=stock)
        product.save()#insert
        return redirect('product_list')
    return render(request, 'productapp/product_form.html')

def product_update(request,id):
    product=get_object_or_404(Product, id=id)
    if request.method == 'POST':
        name = request.POST.get('name')
        price = request.POST.get('price')
        description = request.POST.get('description')
        stock = request.POST.get('stock')
        product = Product(name=name, price=price, description=description, stock=stock)
        product.save()#
        return redirect('product_list')
    return render(request, 'productapp/product_form.html',{'product':product})

def product_delete(request,id):
    product=get_object_or_404(Product, id=id)
    product.delete()
    return redirect('product_list')






