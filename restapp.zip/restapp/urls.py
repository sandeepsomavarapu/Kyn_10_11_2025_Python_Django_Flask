
from django.urls import path
from . import views
urlpatterns=[
path('books/',views.getBooks),
path('addbook', views.addBook),
path('update/<int:pk>', views.updateBook),
path('delete/<int:pk>', views.deleteBook)
]