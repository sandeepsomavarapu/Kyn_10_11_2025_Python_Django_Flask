from django.shortcuts import render
from .serializers import BookSerializer
from .models import Book
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework import status
# Create your views here.
#get,post,put,delete

@api_view(['GET'])
def getBooks(request):
    books=Book.objects.all()
    print("Books fecthed",books)
    serializer=BookSerializer(books,many=True)
    print("Serializer", serializer.data)
    return JsonResponse(serializer.data, safe=False,status=status.HTTP_200_OK)

@api_view(['POST'])
def addBook(request):
    serializer=BookSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
    return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
@api_view(['PUT'])
def updateBook(request, pk):
    try:
        book=Book.objects.get(pk=pk)
    except Book.DoesNotExist:
        return JsonResponse({'error':'Book not found'}, status=status.HTTP_404_NOT_FOUND)
    serializer=BookSerializer(book, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return JsonResponse(serializer.data)
    return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    

@api_view(['DELETE'])
def deleteBook(request, pk):
    try:
        book=Book.objects.get(pk=pk)
    except Book.DoesNotExist:
        return JsonResponse({'error':'Book not found'}, status=status.HTTP_404_NOT_FOUND)
    book.delete()
    return JsonResponse({'message':'Book deleted successfully'}, status=status.HTTP_204_NO_CONTENT)