from django.shortcuts import render

# Create your views here.
def tableData(request):
    return render(request, 'table.html')