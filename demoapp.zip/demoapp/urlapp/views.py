from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def appurlinfo(request):
    response='<h1>am from appurlinfo..</h1>'
    return HttpResponse(response)