from urlapp import views
from django.urls import path
urlpatterns=[
    path('demo/',views.appurlinfo)
]