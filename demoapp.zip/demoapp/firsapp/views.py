from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def display(request):
    return render(request, 'one.html')

def loginDemo(request):
    response='<h1>am from login..</h1>'
    return HttpResponse(response)