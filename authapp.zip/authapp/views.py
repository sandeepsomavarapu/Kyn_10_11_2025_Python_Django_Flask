from django.shortcuts import render

# Create your views here.

from django.contrib.auth import login
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required

def signup_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password=request.POST.get('password')
        confirm_password=request.POST.get('confirm_password')

        if password==confirm_password:
            user = User.objects.create_user(username=username, password=password)
            login(request,user)
            messages.success(request, 'User created successfully. Please log in.')
            return redirect('home')
        else:
            messages.error(request, 'Passwords do not match. Please try again.')
    return render(request, 'authapp/signup.html')
@login_required(login_url='login')
def home(request):
    return render(request, 'authapp/home.html')